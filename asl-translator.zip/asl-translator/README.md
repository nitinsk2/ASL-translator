# Real-Time American Sign Language Translator

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**CSE 474 – Introduction to Machine Learning, Spring 2026**  
**University at Buffalo**

**Team:** Nitin Suresh Kumar, Yash Sabale, Vanshaj Arora

---

## 🎯 Project Overview

A real-time ASL (American Sign Language) translator that bridges the communication gap between signing and non-signing individuals. Our system uses a multi-stage deep learning pipeline to recognize ASL gestures from video input and generate natural language output.

### Key Features

- **Real-time webcam recognition** of ASL alphabet (A-Z)
- **99.66% accuracy** on static gesture recognition
- **Multi-stage pipeline** from static → dynamic → contextual translation
- **GPU-accelerated inference** for real-time performance

---

## 📊 Results

### Stage 1: Static ASL Alphabet Recognition

| Metric | Value |
|--------|-------|
| Validation Accuracy | **99.66%** |
| Macro F1-Score | 1.00 |
| Inference Time | ~15ms/frame |
| Model Size | 9.2 MB |

### Stage 2: Dynamic Word Recognition (WLASL100)

| Metric | Value |
|--------|-------|
| Top-1 Accuracy | **58.3%** |
| Top-5 Accuracy | **82.1%** |
| Architecture | I3D (Inflated 3D ConvNet) |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    ASL TRANSLATOR PIPELINE                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────┐    ┌─────────────┐    ┌─────────────┐    ┌───────┐ │
│  │ Webcam  │───▶│ MediaPipe   │───▶│ MobileNetV2 │───▶│ Letter│ │
│  │ Input   │    │ (optional)  │    │ Classifier  │    │ Output│ │
│  └─────────┘    └─────────────┘    └─────────────┘    └───────┘ │
│                                                                   │
│  STAGE 1: Static Recognition (Completed - 99.66% accuracy)       │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────┐    ┌─────────────┐    ┌─────────────┐    ┌───────┐ │
│  │ Video   │───▶│ Frame       │───▶│ I3D + LSTM  │───▶│ Word  │ │
│  │ Input   │    │ Sampling    │    │ Classifier  │    │ Output│ │
│  └─────────┘    └─────────────┘    └─────────────┘    └───────┘ │
│                                                                   │
│  STAGE 2: Dynamic Recognition (In Progress - 58.3% accuracy)    │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────┐    ┌─────────────┐    ┌─────────────┐    ┌───────┐ │
│  │ Words   │───▶│ Embedding   │───▶│ GPT-2 +     │───▶│ Text  │ │
│  │ Sequence│    │ Projection  │    │ LoRA        │    │ Output│ │
│  └─────────┘    └─────────────┘    └─────────────┘    └───────┘ │
│                                                                   │
│  STAGE 3: Contextual Translation (Planned)                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites

```bash
# Python 3.8+
pip install torch torchvision opencv-python numpy matplotlib seaborn scikit-learn

# Optional: MediaPipe for better hand detection
pip install mediapipe
```

### Run the Demo

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/asl-translator.git
cd asl-translator

# Run real-time demo (requires webcam)
cd demo
python realtime_asl_demo.py

# With trained model
python realtime_asl_demo.py --model ../models/asl_mobilenetv2.pth

# With MediaPipe hand detection
python realtime_asl_demo.py --model ../models/asl_mobilenetv2.pth --use-mediapipe
```

### Demo Controls

| Key | Action |
|-----|--------|
| `Q` | Quit demo |
| `C` | Clear text |
| `Space` | Add space to text |
| `B` | Backspace |
| `Enter` | Confirm current letter |

---

## 📁 Project Structure

```
asl-translator/
├── README.md                 # This file
├── requirements.txt          # Python dependencies
├── demo/
│   └── realtime_asl_demo.py  # Real-time webcam demo
├── notebooks/
│   ├── stage1_training.ipynb # MobileNetV2 training (ASL Alphabet)
│   └── stage2_wlasl_i3d.ipynb # I3D training (WLASL)
├── src/
│   ├── models.py             # Model architectures
│   ├── datasets.py           # Dataset classes
│   └── utils.py              # Helper functions
├── models/
│   └── asl_mobilenetv2.pth   # Trained Stage 1 model
├── data/                     # Dataset directory (not in repo)
└── docs/
    └── milestone_report.pdf  # Project milestone document
```

---

## 📚 Datasets

### Stage 1: ASL Alphabet (Kaggle)
- **Size:** 87,000 images, 29 classes
- **Classes:** A-Z + del, nothing, space
- **Source:** [Kaggle ASL Alphabet](https://www.kaggle.com/datasets/grassknoted/asl-alphabet)

### Stage 2: WLASL
- **Size:** 21,000 videos, 2,000 glosses
- **Subset Used:** WLASL100 (100 most common words)
- **Source:** [WLASL GitHub](https://github.com/dxli94/WLASL)

---

## 🔬 Training

### Stage 1: Static Recognition

```bash
# Run on Kaggle or locally
# See notebooks/stage1_training.ipynb

# Training configuration
- Model: MobileNetV2 (ImageNet pretrained)
- Optimizer: Adam (lr=1e-3, then 1e-4 after unfreezing)
- Epochs: 10
- Batch size: 32
- Data augmentation: flip, rotation, color jitter
```

### Stage 2: Dynamic Recognition

```bash
# See notebooks/stage2_wlasl_i3d.ipynb

# Training configuration
- Model: I3D (Inflated 3D ConvNet)
- Input: 32 frames @ 224x224
- Optimizer: Adam (lr=1e-4)
- Epochs: 30
- Batch size: 8
```

---

## 📈 Experimental Results

### Stage 1 Confusion Analysis

Misclassifications occur between visually similar hand configurations:
- K ↔ U (1 error)
- N ↔ M (2 errors)  
- S ↔ T (1 error)

These are challenging even for human observers due to subtle finger positioning differences.

### Stage 2 Observations

- Accuracy plateaus around epoch 15-20 (consistent with Li et al., WACV 2020)
- Top-5 accuracy (~82%) significantly higher than Top-1 (~58%)
- Larger datasets (WLASL300/2000) show slower plateau but similar final accuracy
- Adding pose stream can improve results by 5-7%

---

## 🔗 References

1. Carreira, J., & Zisserman, A. (2017). Quo Vadis, Action Recognition? CVPR.
2. Li, D., et al. (2020). Word-level Deep Sign Language Recognition from Video. WACV.
3. Wong, R., et al. (2024). Sign2GPT: Leveraging LLMs for Sign Language Translation. ICLR.
4. Bora, J., et al. (2022). Sign Language Recognition using MediaPipe.
5. Rajasekar, P., et al. (2025). Real-Time Sign Language Recognition using Deep Learning.

---

## 👥 Team

| Name | Role |
|------|------|
| Nitin Suresh Kumar | I3D Implementation, Stage 2 |
| Yash Sabale | MobileNetV2 Training, Stage 1 |
| Vanshaj Arora | MediaPipe Integration, Demo |

---

## 📄 License

This project is for educational purposes as part of CSE 474 at University at Buffalo.

---

## 🙏 Acknowledgments

- Professor and TAs of CSE 474, Spring 2026
- Kaggle for ASL Alphabet dataset
- WLASL dataset creators (Li et al.)
- PyTorch and MediaPipe teams
